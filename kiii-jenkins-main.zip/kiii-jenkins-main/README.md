# kiii-jenkins
Repo for the Jenkins exercises, for the DevOps course at FCSE.
